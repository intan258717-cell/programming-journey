﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyProject_TOKOBUNGAMINI
{
    internal class Program
    {
        // Array untuk menyimpan nama bunga dan harga
        static string[] namaBunga = { "Mawar", "Melati", "Tulip", "Anggrek" };
        static int[] hargaBunga = { 15000, 10000, 20000, 25000 };

        static void Main(string[] args)
        {
            Console.WriteLine("======================================");
            Console.WriteLine("  SELAMAT DATANG DI TOKO BUNGA MINI   ");
            Console.WriteLine("======================================");


            TampilkanMenu();
            ProsesPesanan();

            Console.WriteLine("\n=======================================");
            Console.WriteLine("  TERIMA KASIH, SELAMAT BERBELANJA KEMBALI!   ");
            Console.WriteLine("=====================================");


        }
        // Fungsi/Method untuk menampilkan menu
        static void TampilkanMenu()
        {
            Console.WriteLine("\n--- Daftar Bunga ---");
            for (int i = 0; i < namaBunga.Length; i++) // perulangan for
            {
                Console.WriteLine($"{i + 1}. {namaBunga[i]} - Rp {hargaBunga[i]:000}");
                
            }
            Console.WriteLine("--------------------");

        }

        // Fungsi untuk memproses pesanan
        static void ProsesPesanan()
        {
            int totalHarga = 0;
            bool tambahLagi = true;

            while (tambahLagi) // Perulangan while
            {
                Console.Write($"Masukkan nomor bunga yang ingin dibeli (1-4): ");
                if (int.TryParse(Console.ReadLine(), out int pilihan) && pilihan >= 1 && pilihan <= namaBunga.Length) // Percabangan if-else
                {
                    Console.Write($"Masukkan jumlah {namaBunga[pilihan - 1]}: ");
                    if (int.TryParse(Console.ReadLine(), out int jumlah) && jumlah > 0)
                    {
                        totalHarga += hargaBunga[pilihan - 1] * jumlah;
                        Console.WriteLine("Pesanan ditambahkan.");
                    }
                    else
                    {
                        Console.WriteLine("Input jumlah tidak valid.");
                    }
                }
                else
                {
                    Console.WriteLine("Input nomor bunga tidak valid.");
                }

                Console.Write("Tambah pesanan lain? (y/n): ");
                string respon = Console.ReadLine().ToLower();
                if (respon != "y")
                {
                    tambahLagi = false;
                }
            }
            Console.WriteLine($"\nTotal harga yang harus dibayar: Rp {totalHarga:00}");
        }
    }
}
